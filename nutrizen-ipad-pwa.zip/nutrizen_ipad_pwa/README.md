# NutriZen by Allison - iPad PWA gratuita

Este paquete convierte el HTML original en una app web instalable para iPad. No requiere App Store ni cuenta paga de Apple si se usa como PWA.

## Archivos incluidos

- `index.html`: la app principal NutriZen CRM & Agenda.
- `manifest.webmanifest`: metadatos para que iPad la reconozca como app instalable.
- `service-worker.js`: cache básico para abrir la app sin conexión después de la primera carga.
- `icons/`: iconos para pantalla de inicio y manifest.

## Cómo publicarla gratis con GitHub Pages

1. Crea una cuenta gratuita en GitHub si no tienes una.
2. Crea un repositorio nuevo, por ejemplo `nutrizen-app`.
3. Sube todos los archivos de este paquete a la raíz del repositorio: `index.html`, `manifest.webmanifest`, `service-worker.js` y la carpeta `icons`.
4. En GitHub, entra a `Settings > Pages`.
5. En `Build and deployment`, selecciona `Deploy from a branch`.
6. Selecciona la rama `main` y la carpeta `/root`, y guarda.
7. GitHub te dará una URL HTTPS pública. Abre esa URL en Safari del iPad.

## Cómo instalarla en iPad

1. Abre la URL publicada en Safari.
2. Toca el botón Compartir.
3. Toca `Agregar a pantalla de inicio`.
4. Confirma el nombre `NutriZen`.
5. Abre la app desde el nuevo icono de la pantalla de inicio.

## Notas importantes

- La app guarda datos localmente en el iPad usando `localStorage`.
- Para evitar perder datos, usa `Ajustes > Backup JSON` periódicamente.
- Puedes restaurar datos con `Ajustes > Restaurar JSON`.
- El modo offline básico funciona después de abrir la app al menos una vez con internet.
- Si se necesita sincronización entre varios iPads, usuarios con contraseña, o base de datos en la nube, hay que agregar backend. Eso puede hacerse con planes gratuitos, pero ya es una segunda fase.
